# Maintainer: Chris Su <Chris@lesscrowds.org>

EAPI=9

MY_PN="${PN//-bin/}"
MY_P="${MY_PN}-${PV}"

SRC_URI="https://github.com/jgm/${MY_PN}/releases/download/${PV}/${MY_P}-linux-amd64.tar.gz"

KEYWORDS="~amd64"
DESCRIPTION="Conversion between markup formats"
HOMEPAGE="https://pandoc.org"
LICENSE="GPL-2"

RESTRICT="mirror bindist"
SLOT="0"
IUSE=""

RDEPEND="!app-text/${MY_PN}"

S="${WORKDIR}/${MY_P}"

QA_PRESTRIPPED="
    usr/bin/${MY_PN}
    usr/bin/${MY_PN}-citeproc
    "

src_unpack() {
    default

    find . -name "pandoc*.gz" | xargs gunzip
}

src_install() {
    cd "${S}/bin" || die
    dobin "${MY_PN}"
    dobin "${MY_PN}-citeproc"

    cd "${S}/share/man/man1" || die
    doman "${MY_PN}.1"
    doman "${MY_PN}-citeproc.1"
}
