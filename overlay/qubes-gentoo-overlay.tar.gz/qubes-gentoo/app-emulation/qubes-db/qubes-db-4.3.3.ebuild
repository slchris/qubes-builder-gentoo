# Maintainer: Chris Su <Chris@lesscrowds.org>

EAPI=8

PYTHON_COMPAT=( python3_{11..13} )

DISTUTILS_OPTIONAL=1
DISTUTILS_USE_PEP517=setuptools

inherit git-r3 multilib distutils-r1 qubes

if [[ ${PV} == *9999 ]]; then
	EGIT_COMMIT=HEAD
else
	EGIT_COMMIT="v${PV}"
fi

EGIT_REPO_URI="https://github.com/QubesOS/qubes-core-qubesdb.git"

KEYWORDS="amd64"
DESCRIPTION="QubesDB libs and daemon service"
HOMEPAGE="http://www.qubes-os.org"
LICENSE="GPL-2"

SLOT="0"
IUSE=""

DEPEND="app-emulation/qubes-libvchan-xen
        ${PYTHON_DEPS}
        "
RDEPEND="${DEPEND}"
PDEPEND=""

src_prepare() {
    qubes_verify_sources_git "${EGIT_COMMIT}"
    default
}

src_compile() {
    myopt="${myopt} DESTDIR=${D} SYSTEMD=1 BACKEND_VMM=xen"
    emake ${myopt} all
}

src_install() {
    emake ${myopt} install

    dodir /usr/lib/systemd/system/
    insopts -m 0644
    insinto /usr/lib/systemd/system/
    doins daemon/qubes-db.service
}

pkg_postinst() {
    systemctl enable qubes-db.service
}

pkg_postrm() {
    systemctl disable qubes-db.service
}