# Maintainer: Chris Su <Chris@lesscrowds.org>

EAPI=8

PYTHON_COMPAT=( python3_{11..13} )
DISTUTILS_OPTIONAL=1
DISTUTILS_USE_PEP517=setuptools

inherit git-r3 multilib distutils-r1 qubes

if [[ ${PV} == *9999 ]]; then
	EGIT_COMMIT=HEAD
else
	EGIT_COMMIT="v${PV}"
fi

EGIT_REPO_URI="https://github.com/QubesOS/qubes-linux-utils.git"

KEYWORDS="amd64"
DESCRIPTION="Common Linux files for Qubes VM"
HOMEPAGE="http://www.qubes-os.org"
LICENSE="GPL-2"

SLOT="0"
IUSE=""

DEPEND="app-emulation/qubes-libvchan-xen
        media-gfx/imagemagick
        dev-libs/icu
        dev-python/pycairo[${PYTHON_USEDEP}]
        dev-python/pillow[${PYTHON_USEDEP}]
        dev-python/numpy[${PYTHON_USEDEP}]
        ${PYTHON_DEPS}
        "
RDEPEND="${DEPEND}"
PDEPEND=""

src_prepare() {
    qubes_verify_sources_git "${EGIT_COMMIT}"
    default
}

src_compile() {
    myopt="${myopt} DESTDIR="${D}" BACKEND_VMM=xen LIBDIR=/usr/$(get_libdir)"
    emake ${myopt} all
}

src_install() {
    emake ${myopt} install
}
